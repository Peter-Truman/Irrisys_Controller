# IRRISYS Irrigation Controller

PIC18F2525-based irrigation monitoring system

## Hardware
- MCU: PIC18F2525 @ 32MHz (8MHz internal + 4x PLL)
- Display: 20x4 LCD (4-bit mode)
- Input: Rotary encoder + pushbutton
- Sensors: 3 configurable inputs